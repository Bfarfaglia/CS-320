package Task;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class TaskServiceTest1 {

	//Verify Update task name works correctly
	@Test
	@DisplayName("Test to update task name")
	@Order(1)
	void testUpdateTaskName() {
		TaskService service = new TaskService();
		service.addTask("Task Name", "Description");
		service.updateTaskName("Updated Task Name", "1");
		service.displayTaskList();
		assertEquals("Updated Name", service.getTask("1").getTaskName(), "Task Name was not updated.");
		
	}
	
	//Verify Update task description works correctly
	@Test
	@DisplayName("Test to update task description")
	@Order(2)
	void testUpdateTaskDescription() {
		TaskService service = new TaskService();
		service.addTask("Task Name", "Description");
		service.updateTaskDescription("Updated Task Description", "2");
		service.displayTaskList();
		assertEquals("Updated Description", service.getTask("2").getTaskDescription(), "Task Description was not updated.");
			
	}
		
	//Verify Add task works correctly
	@Test
	@DisplayName("Test to add task")
	@Order(3)
	void testAddTask() {
		TaskService service = new TaskService();
		service.addTask("Task Name", "Description");
		service.displayTaskList();
		assertNotNull(service.getTask("3"), "Task was not added correctly");
	}
	
	//Verify Delete task works correctly
	@Test
	@DisplayName("Test to delete task")
	@Order(4)
	void testDeleteContact() {
		TaskService service = new TaskService();
		service.addTask("Task Name", "Description");
		service.deleteTask("4");
		ArrayList<Task> taskListEmpty = new ArrayList<Task>();
		service.displayTaskList();
		assertEquals(service.taskList, taskListEmpty, "The contact was not deleted.")
	}
			

}

