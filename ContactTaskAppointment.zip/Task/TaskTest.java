package Task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest1 {

	//Test to verify task ID is not longer than 10 characters
	@Test
	@DisplayName("Task ID must be 10 characters or less")
	void testTaskIDLength() {
		Task task = new Task("Name", "Description");
		if (task.getTaskID().length > 10) {
			fail("Task ID is longer than 10 characters.");
		}
	}
	
	//Test to verify task name is not longer than 20 characters
	@Test
	@DisplayName("Task Name must be 20 characters or less")
	void testTaskNameLength() {
		Task task = new Task("Really long name that's over twenty characters", "Description");
		if (task.getTaskName().length() > 20) {
			fail("Task Name is longer than 20 characters.");
		}
	}
	
	//Test to verify that task description is not longer than 50 characters
	@Test
	@DisplayName("Task Description must be 50 characters or less")
	void testTaskDescriptionLength() {
		Task task = new Task("Name", "Really really super enormous gigantic mega amazingly long description that is definitely absolutely longer than fifty characters");
		if (task.getTaskDescription().(length) > 50) {
			fail("Task Description is longer than 50 characters.");
		}
	}
	
	//Test to verify task name is not null
	@test
	@DisplayName("Task Name must not be null")
	void testTaskNameNull() {
		Task task = new Task(null, "Description");
		assertNotNull(task.getTaskName(), "Task Name was null.");
	}
	
	//Test to verify task description is not null
	@Test
	@DisplayName("Task Description must not be null.")
	void testTaskDescriptionNull() {
		Task task = new Task("Name", null);
		assertNotNull(task.getTaskDescription(), "Task Description was null.");
	}

}
