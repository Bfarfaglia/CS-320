package Task;

import java.util.ArrayList;

public class TaskService {
	
	public ArrayList<Task> taskList = new ArrayList<Task>(); // Array list to hold tasks
	
	public void displayTaskList() {
		for (int counter = 0; counter < taskList.size(); counter++) {
			System.out.println("\t Task ID: " + taskList.get(counter).getTaskID());
			System.out.println("\t Task Name: " + taskList.get(counter).getTaskName());
			System.out.println("\t Task Description: " + taskList.get(counter).getTaskDescription());
			
		}
	}
	
	//Add Tasks
	public void addTask(String taskName, String taskDescription) {
		Task task = new Task(taskName, taskDescription);
		taskList.add(task);
	}
	
	//Delete Task
	public void deleteTask(String taskID) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskID().equals(taskID)) {
				taskList.remove(counter);
				break;
			}
			if (counter == taskList.size() - 1) {
				System.out.println("Task ID " + taskID + " not found.");
			}
		}
	}
	
	//Update Task Name
	public void updateTaskName(String updatedString, String taskID) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskID().equals(taskID)) {
				taskList.get(counter).setTaskName(updatedString);
				break;
			}
			if (counter == taskList.size() - 1) {
				System.out.println("Task ID " + taskID + " not found.");
			}
		}
	}
	
	//Update Task Description
	public void updateTaskDescription(String updatedString, String taskID) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getTaskID().equals(taskID)) {
				taskList.get(counter).setTaskDescription(updatedString);
				break;
			}
			if (counter == taskList.size() - 1) {
				System.out.println("Task ID " + taskID + " not found.");
			}
		}
	}
}
