package Appointment;

import java.util.concurrent.atomic.AtomicLong;
import java.util.Calendar;
import java.util.Date;

public class Appointment {

	private final String appointmentID;
	private Date appointmentDate;
	private String appointmentDescription;
	private static AtomicLong idGenerator = new AtomicLong();
	
	//Constructors
	
	@SuppressWarnings("deprecation")
	public Appointment(Date appointmentDate, String appointmentDescription) {
		
		this.appointmentID = String.valueOf(idGenerator.getAndIncrement());
		
		if (appointmentDate == null) {
			this.appointmentDate = new Date(2025, Calendar.JANUARY, 1);
		}
		else if (appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Cannot make appointment before current date.");
		}
		else {
			this.appointmentDate = appointmentDate;
		}
		
		if (appointmentDescription == null || appointmentDescription.isEmpty()) {
			this.appointmentDescription = "NULL";
		}
		else if (appointmentDescription.length() > 50) {
			this.appointmentDescription = appointmentDescription.substring(0, 50);
		}
		else {
			this.appointmentDescription = appointmentDescription;
		}
	}
	
	//Setters
	
	@SuppressWarnings("deprecation")
	public void setAppointmentDate(Date appointmentDate) {
		if (appointmentDate == null) {
			this.appointmentDate = new Date(2025, Calendar.JANUARY, 1);
		}
		else if (appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Cannot make appointment before current date.");
		}
		else {
			this.appointmentDate = appointmentDate;
		}
	}
	
	public void setAppointmentDescription(String appointmentDescription) {
		if (appointmentDescription == null || appointmentDescription.isEmpty()) {
			this.appointmentDescription = "NULL";
		}
		else if (appointmentDescription.length() > 50) {
			this.appointmentDescription = appointmentDescription.substring(0, 50);
		}
		else {
			this.appointmentDescription = appointmentDescription;
		}
	}
	
	//Getters
	
	public String getAppointmentID() {
		return appointmentID;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getAppointmentDescription() {
		return appointmentDescription;
	}
	
	

}
