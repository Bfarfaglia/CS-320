package Appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import Appointment.Appointment;

class AppointmentTest {
	
	private Date Date(int i, int january, int j) {
		return null;
	}
	
	//Test to verify Appointment ID is 10 characters or less
	@Test
	@DisplayName("Appointment ID cannot be longer than 10 characters")
	void testAppointmentIDLength() {
		Appointment appointment = new Appointment(Date(2025, Calendar.JANUARY, 1), "Description");
		if (appointment.getAppointmentID().length() > 10) {
			fail("Appointment ID is longer than 10 characters");
		}
		
	}
	
	//Test to verify Appointment Description is 50 characters or less
	@Test
	@DisplayName("Appointment Description cannot be longer than 50 characters")
	void testAppointmentDescriptionLength() {
		Appointment appointment = new Appointment(Date(2025, Calendar.JANUARY, 1), "123456789012345678901234567890123456789012345678901");
		if (appointment.getAppointmentDescription().length() > 50) {
			fail("Appointment Description is longer than 50 characters");
	    }
     }
	
	//Test to verify appointment date is not in the past
	@Test
	@DisplayName("Appointment Date cannot be before current date.")
	void testAppointmentDateNotInPast() {
		Appointment appointment = new Appointment (Date(2024, Calendar.JANUARY, 1), "Description");
		if (appointment.getAppointmentDate().before(new Date())) {
			fail("Appointment Date is before current date.");
		}
	}
	
	//Test to verify appointment date is not null
	@Test
	@DisplayName("Appointment Date shall not be null")
	void testAppointmentDateNotNull() {
		Appointment appointment = new Appointment(null, "Description");
		assertNotNull(appointment.getAppointmentDate(), "Appointment Date was null");
	}
	
	//Test to verify appointment description is not null
	@Test
	@DisplayName("Appointment Description shall not be null")
	void testAppointmentDescriptionNotNull() {
		Appointment appointment = new Appointment(Date(2025, Calendar.JANUARY, 1), null);
		assertNotNull(appointment.getAppointmentDescription(), "Appointment Description was null");
	}
	
}
