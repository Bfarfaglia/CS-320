package Appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;

import Appointment.Appointment;
import Appointment.AppointmentService;

class AppointmentServiceTest {
	
	private Date Date(int i, int january, int j) {
		return null;
	}
    
	//Test to add appointment
	@Test
	@DisplayName("Test to verify service can add an appointment.")
	@Order(1)
	void testAddAppointment() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2025, Calendar.JANUARY, 1), "Description");
		service.displayAppointmentList();
		assertNotNull(service.getAppointment("1"), "Appointment not added correctly");
	}
	
	//Test to delete appointment
	@Test
	@DisplayName("Test to verify service can delete appointment.")
	@Order(2)
	void testDeleteAppointment() {
		AppointmentService service = new AppointmentService();
		service.addAppointment(Date(2025, Calendar.JANUARY, 1), "Description");
		service.deleteAppointment("1");
		ArrayList<Appointment> appointmentListEmpty = new ArrayList<Appointment>(); //Checks that appointment list is empty by creating a new list to compare it with
		service.displayAppointmentList();
		assertEquals(service.appointmentList, appointmentListEmpty, "The appointment was not deleted correctly.");
	}

}
