package Appointment;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	
	public ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	
	//Display all appointments
	public void displayAppointmentList() {
		for(int counter = 0; counter < appointmentList.size(); counter++) {
			System.out.println("\t Appointment ID: " + appointmentList.get(counter).getAppointmentID());
			System.out.println("\t Appointment Date: " + appointmentList.get(counter).getAppointmentDate());
			System.out.println("\t Appointment Description: " + appointmentList.get(counter).getAppointmentDescription());
			
		}
	}
	
	//Add new appointment
    public void addAppointment(Date appointmentDate, String appointmentDescription) {
		Appointment appointment = new Appointment(appointmentDate, appointmentDescription);
		appointmentList.add(appointment);
	}
	
	//Return an appointment with appointment ID. Necessary for delete appointment
    public Appointment getAppointment(String appointmentID) {
    	Appointment appointment = new Appointment(null, null);
    	for (int counter = 0; counter < appointmentList.size(); counter++) {
    		if (appointmentList.get(counter).getAppointmentID().equals(appointmentID)) {
    			appointment = appointmentList.get(counter);
    		}
    	}
    	return appointment;
    }
    
    //Delete appointment
    public void deleteAppointment(String appointmentID ) {
    	for (int counter = 0; counter < appointmentList.size(); counter++) {
    		if (appointmentList.get(counter).getAppointmentID().equals(appointmentID)) {
    			appointmentList.remove(counter);
    			break;
    		}
    		if (counter == appointmentList.size() - 1) {
        		System.out.println("Appointment ID " + appointmentID + " not found.");
    		}	
    	}
    	
    	
    }
	
	

}
