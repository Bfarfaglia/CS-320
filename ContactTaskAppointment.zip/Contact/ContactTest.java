package Contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import Contact.Contact;

public class ContactTest {
	@Test
	@DisplayName("Contact ID cannot be longer than 10 characters")
	void testContactID() { //Verifying that Contact ID does not have more than 10 characters
		Contact contact = new Contact("firstName", "lastName", "phoneNumbr", "address");
		if (contact.getContactID().length() > 10) {
			fail("Contact ID has more than 10 characters.");
		}
	}
	
	@Test
	@DisplayName("Contact First Name cannot be longer than 10 characters")
	void testContactFirstNameLength() { //Verifying that First name does not have more than 10 characters
		Contact contact = new Contact("longFirstName", "lastName", "phoneNumbr", "address");
		if (contact.getFirstName().length() > 10) {
			fail("First Name has more than 10 characters.");
		}
	}
	
	@Test
	@DisplayName("Contact Last Name cannot be longer than 10 characters")
	void testContactLastNameLength() { //Verifying that Last name does not have more than 10 characters
		Contact contact = new Contact("firstName", "LongLastName", "phoneNumbr", "address");
		if (contact.getLastName().length() > 10) {
			fail("Last Name has more than 10 characters.");
		}
	}
	
	@Test
	@DisplayName("Contact Phone Number must be 10 characters")
	void testContactPhoneNumberLength() { //Verifying that Phone Number has exactly 10 characters
		Contact contact = new Contact("firstName", "lastName", "phoneNumber", "address");
		if (contact.getPhoneNumber().length() != 10) {
			fail("Phone Number does not have 10 characters.");
		}
	}
	
	@Test
	@DisplayName("Contact Address cannot be longer than 10 characters")
	void testContactAddressLength() { //Verifying that Address does not have more than 30 characters
		Contact contact = new Contact("firstName", "lastName", "phoneNumbr", "Really Long Address that id definitely way more than thirty characters long");
		if (contact.getAddress().length() > 30) {
			fail("Address has more than 30 characters.");
		}
	}
	
	@Test
	@DisplayName("Contact First Name cannot be null")
	void testContactFirstNameNull() { //Verifies first name is not null
		Contact contact = new Contact(null, "lastName", "phoneNumbr", "address");
		assertNotNull(contact.getFirstName(), "First Name was null.");
	}
	
	@Test
	@DisplayName("Contact Last Name cannot be null")
	void testContactLastNameNull() { //Verifies last name is not null
		Contact contact = new Contact("firstName", null, "phoneNumbr", "address");
		assertNotNull(contact.getLastName(), "Last Name was null.");
	}
	
	@Test
	@DisplayName("Contact Phone Number cannot be null")
	void testContactPhoneNumberNull() { //Verifies phone number is not null
		Contact contact = new Contact("firstName", "lastName", null, "address");
		assertNotNull(contact.getPhoneNumber(), "Phone Number was null.");
	}
	
	@Test
	@DisplayName("Contact Address cannot be null")
	void testContactAddressNull() { //Verifies address is not null
		Contact contact = new Contact("firstName", "lastName", "phoneNumbr", null);
		assertNotNull(contact.getAddress(), "Address was null.");
	}

}
