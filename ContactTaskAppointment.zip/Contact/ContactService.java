package Contact;

import java.util.ArrayList;

public class ContactService {
	
	public ArrayList<Contact> contactList = new ArrayList<Contact>(); // Array list for holding contacts
	
	public void displayContactList() { // Displays all contacts
		for (int counter = 0; counter < contactList.size(); counter++) {
			System.out.println("\t Contact ID: " + contactList.get(counter).getContactID());
			System.out.println("\t First Name: " + contactList.get(counter).getFirstName());
			System.out.println("\t Last Name: " + contactList.get(counter).getLastName());
			System.out.println("\t Phone Number: " + contactList.get(counter).getPhoneNumber());
			System.out.println("\t Address: " + contactList.get(counter).getAddress() + "\n");
			
		}
	}
	
	// Add Contact
	public void addContact(String firstName, String lastName, String phoneNumber, String address) {
		Contact contact = new Contact(firstName, lastName, phoneNumber, address);
		contactList.add(contact);
	}
	
	// Delete Contact
	public void deleteContact(String contactID) {
		for (int counter = 0; counter < contactList.size(); counter++) {
			if (contactList.get(counter).getContactID().equals(contactID)) {
				contactList.remove(counter);
				break;
			}
			if (counter == contactList.size() - 1) {
				System.out.println("Contact ID " + contactID + " not found.");
			}
		}
	}
	
	//Update Contact Information
	public void updateFirstName(String updatedString, String contactID) {
		for (int counter = 0; counter < contactList.size(); counter++) {
			if (contactList.get(counter).getContactID().equals(contactID)) {
				contactList.get(counter).setFirstName(updatedString);
				break;
			}
			if (counter == contactList.size() - 1) {
				System.out.println("Contact ID " + contactID + " not found.");
			}
		}
	}
	
	public void updateLastName(String updatedString, String contactID) {
		for (int counter = 0; counter < contactList.size(); counter++) {
			if (contactList.get(counter).getContactID().equals(contactID)) {
				contactList.get(counter).setLastName(updatedString);
				break;
			}
			if (counter == contactList.size() - 1) {
				System.out.println("Contact ID " + contactID + " not found.");
			}
		}
	}
	
	public void updatePhoneNumber(String updatedString, String contactID) {
		for (int counter = 0; counter < contactList.size(); counter++) {
			if (contactList.get(counter).getContactID().equals(contactID)) {
				contactList.get(counter).setPhoneNumber(updatedString);
				break;
			}
			if (counter == contactList.size() - 1) {
				System.out.println("Contact ID " + contactID + " not found.");
			}
		}
	}
	
	public void updateAddress(String updatedString, String contactID) {
		for (int counter = 0; counter < contactList.size(); counter++) {
			if (contactList.get(counter).getContactID().equals(contactID)) {
				contactList.get(counter).setAddress(updatedString);
				break;
			}
			if (counter == contactList.size() - 1) {
				System.out.println("Contact ID " + contactID + " not found.");
			}
		}
	}

}
