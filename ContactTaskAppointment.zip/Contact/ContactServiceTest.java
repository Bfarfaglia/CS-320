package Contact;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import Contact.Contact;
import Contact.ContactService;
import org.junit.jupiter.api.Order;

@TestMethodOrder(OrderAnnotation.class)
public class ContactServiceTest {
	
	@Test
	@DisplayName("Test to update first name.")
	@Order(1)
	void testUpdateFirstName() {
		ContactService service = new ContactService();
		service.addContact("Donald",  "Duck", "0000000000", "123 Sesame Street");
		service.updateFirstName("Mickey", "1");
		service.displayContactList();
		assertEquals("Mickey", service.getContact("1"), getFirstName(), "First Name was not updated.");
		
	}
	
	@Test
	@DisplayName("Test to update last name.")
	@Order(2)
	void testUpdateLastName() {
		ContactService service = new ContactService();
		service.addContact("Donald",  "Duck", "0000000000", "123 Sesame Street");
		service.updateLastName("Mouse", "2");
		service.displayContactList();
		assertEquals("Mouse", service.getContact("2"), getLastName(), "Last Name was not updated.");
		
	}
	
	@Test
	@DisplayName("Test to update phone number.")
	@Order(3)
	void testUpdatePhoneNumber() {
		ContactService service = new ContactService();
		service.addContact("Donald",  "Duck", "0000000000", "123 Sesame Street");
		service.updatePhoneNumber("5555555555", "3");
		service.displayContactList();
		assertEquals("5555555555", service.getContact("3"), getPhoneNumber(), "Phone Number was not updated.");
		
	}
	
	@Test
	@DisplayName("Test to update address.")
	@Order(4)
	void testUpdateAddress() {
		ContactService service = new ContactService();
		service.addContact("Donald",  "Duck", "0000000000", "123 Sesame Street");
		service.updateAddress("221 B Baker St", "4");
		service.displayContactList();
		assertEquals("221 B Baker St", service.getContact("4"), getAddress(), "Address was not updated.");
		
	}
	
	@Test
	@DisplayName("Test to add contact.")
	@Order(5)
	void testAddContact() {
		ContactService service = new ContactService();
		service.addContact("Donald",  "Duck", "0000000000", "123 Sesame Street");
		service.displayContactList();
		assertEquals(service.getContact("0"), "Contact was not added.");
		
	}
	
	@Test
	@DisplayName("Test to delete contact.")
	@Order(6)
	void testDeleteContact() {
		ContactService service = new ContactService();
		service.addContact("Donald",  "Duck", "0000000000", "123 Sesame Street");
		service.deleteContact("0");
		ArrayList<Contact> contactListEmpty = new ArrayList<Contact>();
		service.displayContactList();
		assertEquals(service.contactList, contactListEmpty, "The contact was not deleted.");
		
	}


	
	




}
